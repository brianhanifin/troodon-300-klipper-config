# troodon-300-klipper-config
This are the configuration files I use for Klipper / Mainsail OS on my Vivedino Troodon (original) 300mm x 300mm x 400mm.
